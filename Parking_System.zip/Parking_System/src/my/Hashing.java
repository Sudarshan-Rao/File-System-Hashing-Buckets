/*=
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package my;

import static my.Adddet.t1;
import static my.Adddet.t2;
import static my.Adddet.t3;
import static my.Adddet.t4;
import static my.Adddet.t5;
import static my.Adddet.t6;
import static my.Search.s1;
import static my.Search.s2;
import static my.Search.s3;
import static my.Search.s4;
import static my.Search.s5;
import static my.Search.s6;
import static my.Search.s7;
import java.util.Scanner;
import java.io.*;
import java.util.*;
import javax.swing.JOptionPane;
import static my.Delete.a1;
import static my.Delete.a2;
import static my.Delete.a3;
import static my.Delete.a4;
import static my.Delete.a5;
import static my.Delete.a6;
import static my.Delete.a7;
import static my.Delete.a8;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;
class Hashing {
    static Scanner sc = new Scanner(System.in);
    static final int bucket_size = 10;
    static final int record_size = 100;
    static final long[] h = new long[20]; //what is the h array used for 
    static int i = 0;
   


    public static class node {

        char[] PID = new char[10];
        String PlateNo = new String(new char[40]);
        String ParkBlock = new String(new char[40]);
        String Date = new String(new char[40]);
        String TimeIn = new String(new char[70]);
        String Location = new String(new char[40]);

        public node link;
       
        

    }
    static node head[] = new node[10];

    static int hashfu(char[] pid) {
       
        int x;
        int sum = pid[0] + pid[1] + pid[2];
        x = (sum % bucket_size) * record_size;
        return x;


    }

    static void pack() throws IOException {
        node q[] = new node[10];
        BufferedWriter file = null;

        try {
            FileWriter fstream = new FileWriter("C:\\Users\\Sudarshan Rao\\Desktop\\FS_PROJECT\\Parking_System\\src\\my\\sam.txt");
            file = new BufferedWriter(fstream);
            int z = 0;
            while (h[z] != 0)
                z++;
            for (int k = 0; k <= z; k++) {
                q[k] = head[k];
                while (q[k] != null) {
                    file.write(q[k].PID);
                    file.write("  |");
                    file.write(q[k].PlateNo);
                    file.write("  |");
                    file.write(q[k].ParkBlock);
                    file.write("  |");
                    file.write(q[k].Date);
                    file.write("  |");
                    file.write(q[k].Location);
                    file.write("  |");
                    file.write(q[k].TimeIn);
                    file.write("  |");

                    file.write("->");

                    q[k] = q[k].link;
                }
                file.write("\n");
            }

            file.close();

        } 
        catch (IOException e) 
        {
            System.err.println("Error: " + e.getMessage());
        }



    }

    public static void write() throws IOException {
        node p = new node();
        node q = new node();

        int count;
        //int usn[]=new int[11];

        System.out.println("Enter the PID:");
       // p.PID = sc.next().toCharArray();
        p.PID=t1.getText().toCharArray();


        System.out.println("Enter the Plate Number:");
        //p.PlateNo = sc.next();
        p.PlateNo=t2.getText();
        System.out.println("Enter the Parking Block");
        //p.ParkBlock = sc.next();
        p.ParkBlock=t3.getText();
        System.out.println("Enter the Date");
        //p.Date = sc.next();
        p.Date=t4.getText();
        System.out.println("Enter the Location");
        //p.Location = sc.next();
        p.Location=t5.getText();
        System.out.println("Enter Time In");
        //p.TimeIn = sc.next();
        p.TimeIn=t6.getText();             

        p.link = null;

        int bucket_no;
        bucket_no = hashfu(p.PID);

        if (bucket_no == 0)
            bucket_no++;

        while (h[i] != 0)
            i++;

        for (int j = 0; j <= i; j++) 
        {
            if (h[j] == bucket_no)
                i = j;
        }

        if (i >= bucket_size) {
            System.out.println("\nit cannot be inserted because it is exceeding the bucket size");
            return;
        }
        h[i] = bucket_no;
        for (int k = 0; k <= i; k++) {

            if (k == i) {
                q = head[k];
                count = 0;
                while ((q != null) && (count < 5)) {
                    count++;
                    q = q.link;

                }
                if (count == 5) {
                    System.out.println("\n overflow");
                    i++;

                    return;
                }

                if (head[k] == null) {
                    head[k] = p;
                    head[k].link = null;

                } else {
                    q = head[k];
                    while (q.link != null) {
                        q = q.link;
                    }
                    q.link = p;
                    //return;
                }
            }

        }
        i++;
        pack();
    }

    static void search() {
        try{
        char[] pid = new char[11];
       // System.out.println("Enter the PID to be searched!");
        //pid = sc.next().toCharArray();
        pid=s4.getText().toCharArray();
        

        int bucket_no;
        bucket_no = hashfu(pid);
        if (bucket_no == 0) {
            bucket_no++;
        }
        int row = -1, k = 0;
        //System.out.println(h[k]);
        while (h[k] != 0) {
            k++;
        }

        for (int j = 0; j < k; j++) {
            if (h[j] == bucket_no) {
                row = j;
                break;
            }
        }

        node q = new node();
        node r = new node();
        
        
        if (row != -1) {
        

            q = head[row];
            r = q.link;
            
        
            if((Arrays.equals(pid, q.PID)) && (q != null)) 
            {
                
            
                 
        //        System.out.println("\nthe information about this pid is\n");
          //      System.out.print(q.PID); 
                String str = new String(q.PID); //System.out.println(q.MID);
                s1.setText(str);
                s2.setText(q.PlateNo);
                //System.out.print("\t"+q.PlateNo);
                s3.setText(q.ParkBlock);
               // System.out.print("\t"+q.ParkBlock);
                s5.setText(q.Date);
                s6.setText(q.Location);
               // System.out.print("\t"+q.Date);
                s7.setText(q.TimeIn);
               // System.out.print("\t"+q.Location);
               // System.out.print("\t"+q.TimeIn);
                JOptionPane.showMessageDialog(null,"SEARCH SUCCESSFUL");
            }
    
            else if((Arrays.equals(pid, r.PID)) && (r != null)) 
            {
            
                
                //System.out.println("\nthe information about this pid is\n");
                //System.out.print(r.PID); 
                String str = new String(r.PID);
                s1.setText(str);
                s2.setText(r.PlateNo);
                //System.out.print("\t"+r.PlateNo);
                s3.setText(r.ParkBlock);
                //System.out.print("\t"+r.ParkBlock);
                s5.setText(r.Date);
                s6.setText(r.Location);
                //System.out.print("\t"+r.Date);
                s7.setText(r.TimeIn);
                
                //System.out.print("\t"+r.Location);
                //System.out.print("\t"+r.TimeIn);
                JOptionPane.showMessageDialog(null,"SEARCH SUCCESSFUL");
                    
            } 
    
            else if ((Arrays.equals(pid, r.link.PID)) && (r.link != null)) 
            {
            
                //System.out.println("\nthe information about this pid is\n");
                //System.out.print(r.PID); 
                String str = new String(r.link.PID); //System.out.println(q.MID);
                s1.setText(str);
                s2.setText(r.link.PlateNo);
                //System.out.print("\t" + r.link.PlateNo);
                s3.setText(r.link.ParkBlock);
               // System.out.print("\t" + r.link.ParkBlock);
                s5.setText(r.link.Date); 
                s6.setText(r.link.Location);
               // System.out.print("\t" + r.link.Date);
                s7.setText(r.link.TimeIn);
               // System.out.print("\t" + r.link.Location);
                //System.out.print("\t" + r.link.TimeIn);
                JOptionPane.showMessageDialog(null,"SEARCH SUCCESSFUL");
            }
        }
        
        else 
        {
            //System.out.println("ERROR");
                s1.setText("");
                s2.setText("");
                s3.setText("");
                s5.setText("");
                s6.setText("");
                s7.setText("");
            JOptionPane.showMessageDialog(null,"SEARCH UNSUCCESSFUL");
        }
    }
        catch(Exception e)
                {
               // System.out.println(e);
                s1.setText("");
                s2.setText("");
                s3.setText("");
                s5.setText("");
                s6.setText("");
                s7.setText("");
                 JOptionPane.showMessageDialog(null, "SEARCH UNSUCESSFUL");
                }
    }

    static void search1() {
        
         try {
        char[] pid = new char[11];
        //System.out.println("Enter the MID to be searched!");
        //mid=sc.next().toCharArray();
        pid = a4.getText().toCharArray();
        //System.out.println(usn);

        int bucket_no;
        bucket_no = hashfu(pid);
        if (bucket_no == 0) {
            bucket_no++;
        }
        int row = -1, k = 0;
        //System.out.println(h[k]);
        while (h[k] != 0) {
            k++;
        }

        for (int j = 0; j < k; j++) {
            if (h[j] == bucket_no) {
                row = j;
                break;
            }
        }

        node q = new node();
        node r = new node();

        if (row != -1) {


            q = head[row];
            r = q.link;

            if ((Arrays.equals(pid, q.PID)) && (q != null)) 
            {

                //System.out.println("\nthe information about this usn is\n");
                //System.out.print(q.MID); 
                String str = new String(q.PID); //System.out.println(q.MID);
                a1.setText(str);
                a2.setText(q.PlateNo);
                //System.out.print("\t"+q.Name);
                a3.setText(q.ParkBlock);
                //System.out.print("\t"+q.Age);
                a5.setText(q.Date);
                a6.setText(q.Location);
                //System.out.print("\t"+q.Category);
                a7.setText(q.TimeIn);
                //System.out.print("\t"+q.Location);
                //System.out.print("\t"+q.Experience);
                JOptionPane.showMessageDialog(null,"SEARCH SUCCESSFUL");

            } 
            else if ((Arrays.equals(pid, r.PID)) && (r != null)) 
            {


                //System.out.println("\nthe information about this usn is\n");
                //System.out.print(r.MID); 
                String str = new String(r.PID);
                a1.setText(str);
                a2.setText(r.PlateNo);
                //System.out.print("\t"+r.Name);
                a3.setText(r.ParkBlock);
                //System.out.print("\t"+r.Age);
                a5.setText(r.Date);
                a6.setText(r.Location);
                //System.out.print("\t"+r.Category);
                a7.setText(r.TimeIn);
                //System.out.print("\t"+r.Location);
                //System.out.print("\t"+r.Experience);
                JOptionPane.showMessageDialog(null,"SEARCH UNSUCCESSFUL");
            } 
            else if ((Arrays.equals(pid, r.link.PID)) && (r.link != null)) 
            {
                //System.out.println("\nthe information about this usn is\n");
                //System.out.print(r.MID); 
                String str = new String(r.link.PID); //System.out.println(q.MID);
                a1.setText(str);
                a2.setText(r.link.PlateNo);
                //System.out.print("\t"+r.link.Name);
                a3.setText(r.link.ParkBlock);
                //System.out.print("\t"+r.link.Age);
                a5.setText(r.link.Date);
                a6.setText(r.link.Location);
                //System.out.print("\t"+r.link.Category);
                a7.setText(r.link.TimeIn);
                //System.out.print("\t"+r.link.Location);
                //System.out.print("\t"+r.link.Experience);
                JOptionPane.showMessageDialog(null,"SEARCH SUCCESSFUL");
            }



            //q=q.link;
            
            }
        else 
        {
                //System.out.println("Error");
                a1.setText("");
                a2.setText("");
                a3.setText("");
                a5.setText("");
                a5.setText("");
                a7.setText("");
                JOptionPane.showMessageDialog(null, "SEARCH UNSUCCESSFUL CANT DELETE");
               
        }
       }
        catch (Exception e) {
            s1.setText("");
            s2.setText("");
            s3.setText("");
            s5.setText("");
            s5.setText("");
            s7.setText("");
            JOptionPane.showMessageDialog(null, "SEARCH UNSUCCESSFUL CANT DELETE");
    }
    }
    

  /*  static void delete_rec() throws IOException {
        char[] pid = new char[11];
        //System.out.println("Enter the MID to be searched!");
        //mid=sc.next().toCharArray();
        pid = a4.getText().toCharArray();
        //System.out.println(usn);

        int bucket_no;
        bucket_no = hashfu(pid);
        if (bucket_no == 0) {
            bucket_no++;
        }
        int row = -1, k = 0;
        //System.out.println(h[k]);
        while (h[k] != 0) {
            k++;
        }

        for (int j = 0; j < k; j++) {
            if (h[j] == bucket_no) {
                row = j;
                break;
            }
        }

        node q = new node();
        node r = new node();

        if (row != -1)
        {
        

            q = head[row];
            r = q.link;

            if ((Arrays.equals(pid, q.PID)) && (q != null)) 
            {
                
                a1.setText("");
                a2.setText("");
                //System.out.print("\t"+q.Name);
                a3.setText("");
                //System.out.print("\t"+q.Age);
                a5.setText("");
                a6.setText("");
                //System.out.print("\t"+q.Category);
                a7.setText("");
                //System.out.print("\t"+q.Location);
                //System.out.print("\t"+q.Experience);
                JOptionPane.showMessageDialog(null,"DELETE SUCCESSFUL");
            } 
            else if ((Arrays.equals(pid, r.PID)) && (r != null)) {


                //System.out.println("\nthe information about this usn is\n");
                //System.out.print(r.MID); 
                String str = new String(r.PID);
                a1.setText("");
                a2.setText("");
                //System.out.print("\t"+r.Name);
                a3.setText("");
                //System.out.print("\t"+r.Age);
                a5.setText("");
                a6.setText("");
                //System.out.print("\t"+r.Category);
                a7.setText("");
                //System.out.print("\t"+r.Location);
                //System.out.print("\t"+r.Experience);
                JOptionPane.showMessageDialog(null, "DELETE SUCCESSFUL");
            } 
            else if ((Arrays.equals(pid, r.link.PID)) && (r.link != null)) 
            {
                //System.out.println("\nthe information about this usn is\n");
                //System.out.print(r.MID); 
                String str = new String(r.link.PID); //System.out.println(q.MID);
                a1.setText("");
                a2.setText("");
                //System.out.print("\t"+r.link.Name);
                a3.setText("");
                //System.out.print("\t"+r.link.Age);
                a5.setText("");
                a6.setText("");
                //System.out.print("\t"+r.link.Category);
                a7.setText("");
                //System.out.print("\t"+r.link.Location);
                //System.out.print("\t"+r.link.Experience);
                JOptionPane.showMessageDialog(null, "DELETE SUCCESSFUL");
            }



            //q=q.link;
            else 
            {
                
                JOptionPane.showMessageDialog(null, "DELETE UNSUCCESSFUL");
            }
        }
    }
    */
     static void delete_rec() throws IOException
    {
       
            char[] pid = new char[11];
            //System.out.println("Enter the PID to be !");
            //mid=sc.next().toCharArray();
            pid = a8.getText().toCharArray();
           

            int bucket_no;
            bucket_no = hashfu(pid);
            if (bucket_no == 0) {
                bucket_no++;
            }
            int row = -1, k = 0;
            //System.out.println(h[k]);
            while (h[k] != 0) {
                k++;
            }

            for (int j = 0; j < k; j++) {
                if (h[j] == bucket_no) {
                    row = j;
                    break;
                }
            }
        
        node temp=new node();
        node prev=new node();
        
        
        temp= head[row];
        prev = null;
 
        // If head node itself holds the key to be deleted
        if (temp != null && Arrays.equals(pid,temp.PID))
        {
            
            head[row] = temp.link;
            a1.setText("");
            a2.setText("");
            //System.out.print("\t"+q.Name);
            a3.setText("");
            //System.out.print("\t"+q.Age);
            a5.setText("");
            a6.setText("");
            //System.out.print("\t"+q.Category);
            a7.setText("");
            //System.out.print("\t"+q.Location);
            //System.out.print("\t"+q.Experience);
            JOptionPane.showMessageDialog(null, "DELETE SUCCESSFUL");
            return ;
        }
 
        
        while (temp != null && !(Arrays.equals(pid,temp.PID)))
        {
             
            prev = temp;
            temp = temp.link;
            a1.setText("");
            a2.setText("");
            //System.out.print("\t"+q.Name);
            a3.setText("");
            //System.out.print("\t"+q.Age);
            a5.setText("");
            a6.setText("");
            //System.out.print("\t"+q.Category);
            a7.setText("");
            //System.out.print("\t"+q.Location);
            //System.out.print("\t"+q.Experience);
            JOptionPane.showMessageDialog(null, "DELETE SUCCESSFUL");
            
        }    
 
        // If key was not present in linked list
        if (temp == null) 
        {
        a1.setText("");
        a2.setText("");
        a3.setText("");
        a5.setText("");
        a5.setText("");
        a7.setText("");
        JOptionPane.showMessageDialog(null,"DELETE UNSUCCESSFUL");
        return;
        }
         prev.link = temp.link;
        
    }
 




    void display() throws IOException {
           
        node q[]=new node[10];
        int z = 0;
        while (h[z] != 0) {
            z++;
        }
        for (int k = 0; k <= z; k++) {
            q[k] = head[k];
            while (q[k] != null) {
                System.out.print(q[k].PID);
                System.out.print("\t" + q[k].PlateNo);
                System.out.print("\t" + q[k].ParkBlock);
                System.out.print("\t" + q[k].Date);
                System.out.print("\t" + q[k].Location);
                System.out.print("\t" + q[k].TimeIn);
                System.out.print("--->");
                q[k] = q[k].link;
            }
            System.out.println("\n");
        }
    }


    public static void main(String[] args) throws IOException {
        int choice;
        Hashing h1 = new Hashing();
        for (;;) {
            System.out.println("\n1-add a record\t2-display\t3-search\t4-exit");
             choice = sc.nextInt();


            switch (choice) {
                case 1:
                     h1.write();
                    break;
                case 2:
                    h1.display();
                    break;
                case 3:
                    h1.search();
                    break;

                case 4:
                    System.exit(1);
                    break;

                default:
                    System.out.println("\n invalid choice");

            }

        }
    }
}